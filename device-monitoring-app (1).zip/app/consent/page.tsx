"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Shield, MapPin, Battery, Monitor, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

export default function ConsentPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    purpose: "",
    monitoringConsent: false,
    finalConsent: false,
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.finalConsent) {
      toast({
        title: "Persetujuan Diperlukan",
        description: "Anda harus memberikan persetujuan eksplisit untuk melanjutkan.",
        variant: "destructive",
      })
      return
    }

    if (!formData.monitoringConsent) {
      toast({
        title: "Pilih Minimal Satu Fitur",
        description: "Pilih minimal satu jenis pemantauan yang diizinkan.",
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch("/api/consent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        toast({
          title: "Persetujuan Berhasil",
          description: "Admin telah diberitahu dan pemantauan akan dimulai.",
        })
        router.push("/user-dashboard")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Terjadi kesalahan saat menyimpan persetujuan.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-6 w-6 text-blue-600" />
              Formulir Persetujuan Pemantauan Perangkat
            </CardTitle>
            <CardDescription>Berikan persetujuan eksplisit untuk pemantauan perangkat Anda</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Nama Lengkap</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="purpose">Tujuan Pemantauan</Label>
                  <Textarea
                    id="purpose"
                    value={formData.purpose}
                    onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
                    placeholder="Contoh: Parental control, pemantauan perangkat perusahaan, dll."
                    required
                  />
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-4">Jenis Pemantauan yang Akan Diaktifkan:</h3>
                <div className="space-y-2 text-sm text-gray-700 mb-4">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4" />
                    <span>Pelacakan GPS dan Lokasi Real-time</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Battery className="h-4 w-4" />
                    <span>Pemantauan Status Baterai</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Monitor className="h-4 w-4" />
                    <span>Berbagi Layar Real-time</span>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="monitoring"
                    checked={formData.monitoringConsent}
                    onCheckedChange={(checked) => setFormData({ ...formData, monitoringConsent: checked as boolean })}
                  />
                  <Label htmlFor="monitoring" className="font-medium">
                    Saya menyetujui semua jenis pemantauan di atas
                  </Label>
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-yellow-800">Penting untuk Diketahui:</h4>
                    <ul className="text-yellow-700 text-sm mt-2 space-y-1">
                      <li>• Anda dapat mencabut akses kapan saja</li>
                      <li>• Admin akan diberitahu secara real-time saat Anda memberikan izin</li>
                      <li>• Semua aktivitas pemantauan dilakukan dengan transparansi penuh</li>
                      <li>• Data Anda akan digunakan sesuai tujuan yang telah dinyatakan</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="finalConsent"
                  checked={formData.finalConsent}
                  onCheckedChange={(checked) => setFormData({ ...formData, finalConsent: checked as boolean })}
                />
                <Label htmlFor="finalConsent" className="text-sm">
                  <strong>Saya memberikan persetujuan eksplisit</strong> untuk pemantauan perangkat sesuai dengan jenis
                  yang telah saya pilih di atas. Saya memahami bahwa ini dilakukan untuk tujuan legal dan saya dapat
                  mencabut akses kapan saja.
                </Label>
              </div>

              <Button type="submit" className="w-full" size="lg">
                Berikan Persetujuan dan Mulai Pemantauan
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
